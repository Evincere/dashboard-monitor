exports.id=8581,exports.ids=[8581],exports.modules={8517:(e,t,s)=>{"use strict";function r(e){let t=e.headers.get("x-forwarded-for");if(t)return t.split(",")[0].trim();let s=e.headers.get("x-real-ip");if(s)return s.trim();let r=e.headers.get("cf-connecting-ip");if(r)return r.trim();let a=e.headers.get("x-client-ip");return a?a.trim():"unknown"}function a(e){return e.headers.get("user-agent")||"unknown"}s.d(t,{getClientIP:()=>r,getUserAgent:()=>a})},12909:(e,t,s)=>{"use strict";s.d(t,{$Y:()=>m,Aq:()=>A,BE:()=>h,En:()=>E,Er:()=>c,Vg:()=>p,Z2:()=>d,cC:()=>_,dM:()=>g,jw:()=>I,lx:()=>R});var r=s(43205),a=s(85663),n=s(72289);let i=process.env.JWT_SECRET,u=process.env.JWT_EXPIRES_IN||"24h",o=process.env.REFRESH_TOKEN_EXPIRES_IN||"7d";if(!i)throw Error("JWT_SECRET environment variable is required");let d=n.Ik({email:n.Yj().email("Invalid email format"),password:n.Yj().min(1,"Password is required")});n.Ik({name:n.Yj().min(1,"Name is required").max(255),email:n.Yj().email("Invalid email format").max(255),password:n.Yj().min(8,"Password must be at least 8 characters").regex(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]/,"Password must contain uppercase, lowercase, number and special character"),role:n.k5(["ROLE_ADMIN","ROLE_USER"]).default("ROLE_USER")});let l=parseInt(process.env.BCRYPT_SALT_ROUNDS||"12"),c=async e=>a.tW(e,l),h=async(e,t)=>a.UD(e,t),p=e=>r.sign(e,i,{expiresIn:u,issuer:"dashboard-monitor",audience:"mpd-concursos"}),_=e=>r.sign({userId:e,type:"refresh"},i,{expiresIn:o,issuer:"dashboard-monitor",audience:"mpd-concursos"}),m=e=>{try{return r.verify(e,i,{issuer:"dashboard-monitor",audience:"mpd-concursos"})}catch(e){return null}},E=e=>{try{let t=r.verify(e,i,{issuer:"dashboard-monitor",audience:"mpd-concursos"});if("refresh"!==t.type)return null;return{userId:t.userId}}catch(e){return null}},A=e=>e&&e.startsWith("Bearer ")?e.substring(7):null,N=new Map,I=(e,t,s)=>{let r=p({userId:e.id,email:e.email,role:e.role});return N.set(r,{userId:e.id,email:e.email,role:e.role,loginTime:new Date,lastActivity:new Date,ipAddress:t,userAgent:s}),r},g=e=>{let t=N.get(e);t&&(t.lastActivity=new Date)},R=e=>{N.delete(e)};setInterval(()=>{let e=new Date;for(let[t,s]of N.entries())e.getTime()-s.lastActivity.getTime()>864e5&&N.delete(t)},36e5)},28303:e=>{function t(e){var t=Error("Cannot find module '"+e+"'");throw t.code="MODULE_NOT_FOUND",t}t.keys=()=>[],t.resolve=t,t.id=28303,e.exports=t},57595:(e,t,s)=>{"use strict";s.d(t,{Lq:()=>l,m6:()=>o,mU:()=>d,ru:()=>u});var r=s(32190),a=s(12909),n=s(98889),i=s(8517);let u=e=>async t=>{try{let s=t.headers.get("authorization"),u=(0,a.Aq)(s);if(!u)return await n._.logSecurityEvent({event:"UNAUTHORIZED_ACCESS_ATTEMPT",ipAddress:(0,i.getClientIP)(t),userAgent:(0,i.getUserAgent)(t),path:t.nextUrl.pathname,timestamp:new Date}),r.NextResponse.json({error:"Authentication required",code:"AUTH_REQUIRED"},{status:401});let o=(0,a.$Y)(u);if(!o)return await n._.logSecurityEvent({event:"INVALID_TOKEN",ipAddress:(0,i.getClientIP)(t),userAgent:(0,i.getUserAgent)(t),path:t.nextUrl.pathname,timestamp:new Date}),r.NextResponse.json({error:"Invalid or expired token",code:"INVALID_TOKEN"},{status:401});return(0,a.dM)(u),t.user=o,e(t)}catch(e){return r.NextResponse.json({error:"Authentication failed",code:"AUTH_ERROR"},{status:500})}},o=(e=>t=>u(async s=>{if(!s.user)return r.NextResponse.json({error:"Authentication required",code:"AUTH_REQUIRED"},{status:401});let a=s.user.role,u={ROLE_ADMIN:2,ROLE_USER:1};return(u[a]||0)<(u[e]||0)?(await n._.logSecurityEvent({event:"INSUFFICIENT_PERMISSIONS",userId:s.user.userId,userRole:a,requiredRole:e,ipAddress:(0,i.getClientIP)(s),path:s.nextUrl.pathname,timestamp:new Date}),r.NextResponse.json({error:"Insufficient permissions",code:"INSUFFICIENT_PERMISSIONS",required:e,current:a},{status:403})):t(s)}))("ROLE_ADMIN"),d=e=>async t=>{if("OPTIONS"===t.method)return new r.NextResponse(null,{status:200,headers:{"Access-Control-Allow-Origin":process.env.ALLOWED_ORIGINS||"*","Access-Control-Allow-Methods":"GET, POST, PUT, DELETE, OPTIONS","Access-Control-Allow-Headers":"Content-Type, Authorization, X-Requested-With","Access-Control-Max-Age":"86400"}});let s=await e(t);return s.headers.set("Access-Control-Allow-Origin",process.env.ALLOWED_ORIGINS||"*"),s.headers.set("Access-Control-Allow-Methods","GET, POST, PUT, DELETE, OPTIONS"),s.headers.set("Access-Control-Allow-Headers","Content-Type, Authorization, X-Requested-With"),s},l=e=>async t=>{let s=await e(t);return s.headers.set("X-Content-Type-Options","nosniff"),s.headers.set("X-Frame-Options","DENY"),s.headers.set("X-XSS-Protection","1; mode=block"),s.headers.set("Referrer-Policy","strict-origin-when-cross-origin"),s.headers.set("Permissions-Policy","camera=(), microphone=(), geolocation=()"),s.headers.set("Strict-Transport-Security","max-age=31536000; includeSubDomains"),s}},67719:(e,t,s)=>{"use strict";s.d(t,{$A:()=>d,$y:()=>l,DK:()=>N,Hs:()=>p,L:()=>A,ME:()=>g,Np:()=>c,Q2:()=>E,TD:()=>_,UD:()=>T,Y4:()=>i,c$:()=>m,eW:()=>u,gG:()=>o,he:()=>R,m5:()=>h,sF:()=>I});var r=s(46101);let a=null;function n(){if(!a){let e={host:process.env.DB_HOST||"127.0.0.1",port:parseInt(process.env.DB_PORT||"3307"),user:process.env.DB_USER||"root",password:process.env.DB_PASSWORD||"root1234",database:process.env.DB_DATABASE||"mpd_concursos",connectionLimit:10,waitForConnections:!0,queueLimit:0,multipleStatements:!1,dateStrings:!1,supportBigNumbers:!0,bigNumberStrings:!1,charset:"utf8mb4"};(a=r.createPool(e)).on("error",e=>{})}return a}async function i(){let e=n();return await e.getConnection()}async function u(e,t){let s=n(),r=await s.getConnection();try{return await r.execute(e,t)}catch(e){throw e}finally{r.release()}}async function o(){return{tables:[],views:[],message:"Schema introspection temporarily disabled"}}async function d(){return{tablesCount:60,message:"Schema overview temporarily using mock data"}}async function l(){return{version:"8.0.43",message:"Database metadata temporarily using mock data"}}async function c(){return{isValid:!0,issues:[],message:"Schema validation temporarily disabled"}}async function h(){return[{TABLE_NAME:"user_entity",total_size_mb:5}]}async function p(){return[]}async function _(){return[]}async function m(){return[]}async function E(){return[]}async function A(){return[]}async function N(){return[]}async function I(){return[]}async function g(){return[]}async function R(){return[]}function T(){return{totalConnections:0,activeConnections:0}}},78335:()=>{},96487:()=>{},98889:(e,t,s)=>{"use strict";s.d(t,{_:()=>n});var r=s(67719);class a{constructor(){this.logQueue=[],this.securityQueue=[],this.isProcessing=!1,this.batchSize=50,this.flushInterval=5e3,setInterval(()=>this.processQueues(),this.flushInterval),process.on("SIGINT",()=>this.flushAll()),process.on("SIGTERM",()=>this.flushAll())}async logActivity(e){this.logQueue.push({...e,timestamp:e.timestamp||new Date}),this.logQueue.length>=this.batchSize&&await this.processQueues()}async logSecurityEvent(e){this.securityQueue.push({...e,timestamp:e.timestamp||new Date}),await this.processQueues()}async processQueues(){if(!this.isProcessing&&(0!==this.logQueue.length||0!==this.securityQueue.length)){this.isProcessing=!0;try{this.logQueue.length>0&&await this.flushAuditLogs(),this.securityQueue.length>0&&await this.flushSecurityEvents()}catch(e){}finally{this.isProcessing=!1}}}async flushAuditLogs(){let e=this.logQueue.splice(0,this.batchSize);if(0!==e.length)try{let t=await (0,r.Y4)();await t.execute(`
        CREATE TABLE IF NOT EXISTS audit_logs (
          id BINARY(16) PRIMARY KEY DEFAULT (UUID_TO_BIN(UUID())),
          event VARCHAR(100) NOT NULL,
          user_id BINARY(16) NULL,
          user_role VARCHAR(50) NULL,
          ip_address VARCHAR(45) NULL,
          user_agent TEXT NULL,
          path VARCHAR(500) NULL,
          method VARCHAR(10) NULL,
          request_body JSON NULL,
          response_status INT NULL,
          response_time INT NULL,
          metadata JSON NULL,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          INDEX idx_event (event),
          INDEX idx_user_id (user_id),
          INDEX idx_ip_address (ip_address),
          INDEX idx_created_at (created_at)
        ) ENGINE=InnoDB
      `);let s=e.map(e=>[e.event,e.userId?`UNHEX(REPLACE('${e.userId}', '-', ''))`:null,e.userRole,e.ipAddress,e.userAgent,e.path,e.method,e.requestBody?JSON.stringify(e.requestBody):null,e.responseStatus,e.responseTime,e.metadata?JSON.stringify(e.metadata):null,e.timestamp]),a=s.map(()=>"(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)").join(", "),n=s.flat();await t.execute(`INSERT INTO audit_logs (event, user_id, user_role, ip_address, user_agent, path, method, request_body, response_status, response_time, metadata, created_at) VALUES ${a}`,n),t.release()}catch(t){this.logQueue.unshift(...e)}}async flushSecurityEvents(){let e=this.securityQueue.splice(0,this.batchSize);if(0!==e.length)try{let t=await (0,r.Y4)();await t.execute(`
        CREATE TABLE IF NOT EXISTS security_events (
          id BINARY(16) PRIMARY KEY DEFAULT (UUID_TO_BIN(UUID())),
          event VARCHAR(100) NOT NULL,
          user_id BINARY(16) NULL,
          user_role VARCHAR(50) NULL,
          required_role VARCHAR(50) NULL,
          ip_address VARCHAR(45) NULL,
          user_agent TEXT NULL,
          path VARCHAR(500) NULL,
          request_count INT NULL,
          limit_value INT NULL,
          threshold_value INT NULL,
          window_ms INT NULL,
          metadata JSON NULL,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          INDEX idx_event (event),
          INDEX idx_ip_address (ip_address),
          INDEX idx_created_at (created_at)
        ) ENGINE=InnoDB
      `);let s=e.map(e=>[e.event,e.userId?`UNHEX(REPLACE('${e.userId}', '-', ''))`:null,e.userRole,e.requiredRole,e.ipAddress,e.userAgent,e.path,e.requestCount,e.limit,e.threshold,e.windowMs,e.metadata?JSON.stringify(e.metadata):null,e.timestamp]),a=s.map(()=>"(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)").join(", "),n=s.flat();await t.execute(`INSERT INTO security_events (event, user_id, user_role, required_role, ip_address, user_agent, path, request_count, limit_value, threshold_value, window_ms, metadata, created_at) VALUES ${a}`,n),t.release()}catch(t){this.securityQueue.unshift(...e)}}async flushAll(){await this.processQueues()}async getAuditLogs(e={}){try{let t=await (0,r.Y4)(),s="WHERE 1=1",a=[];e.event&&(s+=" AND event = ?",a.push(e.event)),e.userId&&(s+=' AND user_id = UNHEX(REPLACE(?, "-", ""))',a.push(e.userId)),e.ipAddress&&(s+=" AND ip_address = ?",a.push(e.ipAddress)),e.startDate&&(s+=" AND created_at >= ?",a.push(e.startDate)),e.endDate&&(s+=" AND created_at <= ?",a.push(e.endDate));let n=Math.min(e.limit||100,1e3),i=e.offset||0,[u]=await t.execute(`SELECT 
          HEX(id) as id,
          event,
          HEX(user_id) as user_id,
          user_role,
          ip_address,
          user_agent,
          path,
          method,
          request_body,
          response_status,
          response_time,
          metadata,
          created_at
        FROM audit_logs 
        ${s}
        ORDER BY created_at DESC
        LIMIT ? OFFSET ?`,[...a,n,i]);return t.release(),u.map(e=>({id:e.id,event:e.event,userId:e.user_id,userRole:e.user_role,ipAddress:e.ip_address,userAgent:e.user_agent,path:e.path,method:e.method,requestBody:e.request_body?JSON.parse(e.request_body):null,responseStatus:e.response_status,responseTime:e.response_time,metadata:e.metadata?JSON.parse(e.metadata):null,timestamp:new Date(e.created_at)}))}catch(e){return[]}}async getSecurityEvents(e={}){try{let t=await (0,r.Y4)(),s="WHERE 1=1",a=[];e.event&&(s+=" AND event = ?",a.push(e.event)),e.ipAddress&&(s+=" AND ip_address = ?",a.push(e.ipAddress)),e.startDate&&(s+=" AND created_at >= ?",a.push(e.startDate)),e.endDate&&(s+=" AND created_at <= ?",a.push(e.endDate));let n=Math.min(e.limit||100,1e3),i=e.offset||0,[u]=await t.execute(`SELECT 
          event,
          HEX(user_id) as user_id,
          user_role,
          required_role,
          ip_address,
          user_agent,
          path,
          request_count,
          limit_value,
          threshold_value,
          window_ms,
          metadata,
          created_at
        FROM security_events 
        ${s}
        ORDER BY created_at DESC
        LIMIT ? OFFSET ?`,[...a,n,i]);return t.release(),u.map(e=>({event:e.event,userId:e.user_id,userRole:e.user_role,requiredRole:e.required_role,ipAddress:e.ip_address,userAgent:e.user_agent,path:e.path,requestCount:e.request_count,limit:e.limit_value,threshold:e.threshold_value,windowMs:e.window_ms,metadata:e.metadata?JSON.parse(e.metadata):null,timestamp:new Date(e.created_at)}))}catch(e){return[]}}}let n=new a}};