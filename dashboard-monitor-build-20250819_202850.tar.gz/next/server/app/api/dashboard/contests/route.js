(()=>{var t={};t.id=6822,t.ids=[6822],t.modules={3295:t=>{"use strict";t.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:t=>{"use strict";t.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},19771:t=>{"use strict";t.exports=require("process")},27910:t=>{"use strict";t.exports=require("stream")},28303:t=>{function e(t){var e=Error("Cannot find module '"+t+"'");throw e.code="MODULE_NOT_FOUND",e}e.keys=()=>[],e.resolve=e,e.id=28303,t.exports=e},28354:t=>{"use strict";t.exports=require("util")},29294:t=>{"use strict";t.exports=require("next/dist/server/app-render/work-async-storage.external.js")},30163:(t,e,s)=>{"use strict";s.r(e),s.d(e,{patchFetch:()=>x,routeModule:()=>d,serverHooks:()=>y,workAsyncStorage:()=>l,workUnitAsyncStorage:()=>m});var r={};s.r(r),s.d(r,{GET:()=>p});var n=s(96559),o=s(48088),a=s(37719),i=s(32190),c=s(67719);let u=new Map;async function p(){try{let t="dashboard-contests",e=function(t){let e=u.get(t);return e&&Date.now()-e.timestamp<3e4?e.data:(u.delete(t),null)}(t);if(e)return i.NextResponse.json({...e,cached:!0,timestamp:new Date().toISOString()});let s=await (0,c.Y4)(),[r,n,o,a,p,d]=await Promise.all([s.execute("SELECT COUNT(*) as total FROM contests"),s.execute(`
        SELECT COUNT(*) as total 
        FROM contests 
        WHERE status = 'active' OR status = 'ACTIVE'
      `),s.execute(`
        SELECT 
          status,
          COUNT(*) as count
        FROM contests 
        GROUP BY status
        ORDER BY count DESC
      `),s.execute(`
        SELECT COUNT(*) as total
        FROM contests 
        WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
      `),s.execute(`
        SELECT 
          c.id,
          c.title,
          c.status,
          COUNT(i.id) as inscription_count
        FROM contests c
        LEFT JOIN inscriptions i ON c.id = i.contest_id
        GROUP BY c.id, c.title, c.status
        ORDER BY inscription_count DESC
        LIMIT 10
      `),s.execute(`
        SELECT 
          COALESCE(type, 'Sin especificar') as type,
          COUNT(*) as count
        FROM contests 
        GROUP BY type
        ORDER BY count DESC
      `)]),l={total:r[0][0]?.total||0,active:n[0][0]?.total||0,recent:a[0][0]?.total||0,byStatus:o[0].map(t=>({status:t.status,count:t.count})),byType:d[0].map(t=>({type:t.type,count:t.count})),topContests:p[0].map(t=>({id:t.id,title:t.title,status:t.status,inscriptionCount:t.inscription_count}))};return u.set(t,{data:l,timestamp:Date.now()}),i.NextResponse.json({...l,cached:!1,timestamp:new Date().toISOString()})}catch(t){return i.NextResponse.json({error:"Failed to fetch contest statistics",timestamp:new Date().toISOString()},{status:500})}}let d=new n.AppRouteRouteModule({definition:{kind:o.RouteKind.APP_ROUTE,page:"/api/dashboard/contests/route",pathname:"/api/dashboard/contests",filename:"route",bundlePath:"app/api/dashboard/contests/route"},resolvedPagePath:"/home/semper/dashboard-monitor/src/app/api/dashboard/contests/route.ts",nextConfigOutput:"standalone",userland:r}),{workAsyncStorage:l,workUnitAsyncStorage:m,serverHooks:y}=d;function x(){return(0,a.patchFetch)({workAsyncStorage:l,workUnitAsyncStorage:m})}},34631:t=>{"use strict";t.exports=require("tls")},41204:t=>{"use strict";t.exports=require("string_decoder")},44870:t=>{"use strict";t.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},55511:t=>{"use strict";t.exports=require("crypto")},63033:t=>{"use strict";t.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},66136:t=>{"use strict";t.exports=require("timers")},67719:(t,e,s)=>{"use strict";s.d(e,{$A:()=>u,$y:()=>p,DK:()=>O,Hs:()=>m,L:()=>f,ME:()=>v,Np:()=>d,Q2:()=>E,TD:()=>y,UD:()=>R,Y4:()=>a,c$:()=>x,eW:()=>i,gG:()=>c,he:()=>C,m5:()=>l,sF:()=>S});var r=s(46101);let n=null;function o(){if(!n){let t={host:process.env.DB_HOST||"127.0.0.1",port:parseInt(process.env.DB_PORT||"3307"),user:process.env.DB_USER||"root",password:process.env.DB_PASSWORD||"root1234",database:process.env.DB_DATABASE||"mpd_concursos",connectionLimit:10,waitForConnections:!0,queueLimit:0,multipleStatements:!1,dateStrings:!1,supportBigNumbers:!0,bigNumberStrings:!1,charset:"utf8mb4"};(n=r.createPool(t)).on("error",t=>{})}return n}async function a(){let t=o();return await t.getConnection()}async function i(t,e){let s=o(),r=await s.getConnection();try{return await r.execute(t,e)}catch(t){throw t}finally{r.release()}}async function c(){return{tables:[],views:[],message:"Schema introspection temporarily disabled"}}async function u(){return{tablesCount:60,message:"Schema overview temporarily using mock data"}}async function p(){return{version:"8.0.43",message:"Database metadata temporarily using mock data"}}async function d(){return{isValid:!0,issues:[],message:"Schema validation temporarily disabled"}}async function l(){return[{TABLE_NAME:"user_entity",total_size_mb:5}]}async function m(){return[]}async function y(){return[]}async function x(){return[]}async function E(){return[]}async function f(){return[]}async function O(){return[]}async function S(){return[]}async function v(){return[]}async function C(){return[]}function R(){return{totalConnections:0,activeConnections:0}}},74075:t=>{"use strict";t.exports=require("zlib")},78335:()=>{},79428:t=>{"use strict";t.exports=require("buffer")},79551:t=>{"use strict";t.exports=require("url")},91645:t=>{"use strict";t.exports=require("net")},94735:t=>{"use strict";t.exports=require("events")},96487:()=>{}};var e=require("../../../../webpack-runtime.js");e.C(t);var s=t=>e(e.s=t),r=e.X(0,[4447,580,6101],()=>s(30163));module.exports=r})();