(()=>{var e={};e.id=5694,e.ids=[5694],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},19771:e=>{"use strict";e.exports=require("process")},27910:e=>{"use strict";e.exports=require("stream")},28303:e=>{function t(e){var t=Error("Cannot find module '"+e+"'");throw t.code="MODULE_NOT_FOUND",t}t.keys=()=>[],t.resolve=t,t.id=28303,e.exports=t},28354:e=>{"use strict";e.exports=require("util")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},34631:e=>{"use strict";e.exports=require("tls")},41204:e=>{"use strict";e.exports=require("string_decoder")},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},55511:e=>{"use strict";e.exports=require("crypto")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},64933:(e,t,r)=>{"use strict";r.r(t),r.d(t,{patchFetch:()=>f,routeModule:()=>l,serverHooks:()=>E,workAsyncStorage:()=>_,workUnitAsyncStorage:()=>x});var s={};r.r(s),r.d(s,{GET:()=>m});var i=r(96559),a=r(48088),n=r(37719),o=r(32190),u=r(46101);let c={host:process.env.DB_HOST||"localhost",port:parseInt(process.env.DB_PORT||"3306"),user:process.env.DB_USER||"root",password:process.env.DB_PASSWORD||"root1234",database:process.env.DB_DATABASE||"mpd_concursos",timezone:"+00:00"};async function d(){let e=null;try{e=await u.createConnection(c);let[r]=await e.execute(`
      SELECT COUNT(*) as count FROM user_entity 
      WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
    `),s=r[0]?.count||0,[i]=await e.execute(`
      SELECT COUNT(*) as count FROM documents WHERE upload_date IS NOT NULL
    `),a=i[0]?.count||0,[n]=await e.execute(`
      SELECT COUNT(*) as count FROM inscriptions
    `),o=n[0]?.count||0,d=0;try{var t;let[r]=await e.execute(`
        SELECT SUM(COALESCE(file_size, 1024)) as total_size FROM documents
      `);t=r[0]?.total_size||0,d=Number((t/0x40000000).toFixed(2))}catch(e){d=.05*a}let m=await p(e);return{activeUsers:s,activeContests:1,processedDocs:a,inscriptions:o,storageUsed:d,recentActivity:m}}catch(e){return{activeUsers:0,activeContests:0,processedDocs:0,inscriptions:0,storageUsed:0,recentActivity:[]}}finally{e&&await e.end()}}async function p(e){let t=[];try{let[r]=await e.execute(`
      SELECT dni, first_name, last_name, email, created_at 
      FROM user_entity 
      ORDER BY created_at DESC 
      LIMIT 5
    `);for(let e of r)t.push({id:`user-${e.dni}`,type:"user",title:"Nuevo usuario registrado",description:`${e.first_name} ${e.last_name}`,timestamp:e.created_at,user:{name:`${e.first_name} ${e.last_name}`,email:e.email}});let[s]=await e.execute(`
      SELECT i.*, u.first_name, u.last_name, u.email
      FROM inscriptions i
      JOIN user_entity u ON i.user_id = u.id
      ORDER BY i.inscription_date DESC
      LIMIT 5
    `);for(let e of s)t.push({id:`inscription-${e.id}`,type:"inscription",title:"Nueva inscripci\xf3n",description:`${e.first_name} ${e.last_name}`,timestamp:e.inscription_date,user:{name:`${e.first_name} ${e.last_name}`,email:e.email}});let[i]=await e.execute(`
      SELECT d.*, u.first_name, u.last_name, u.email
      FROM documents d
      LEFT JOIN user_entity u ON d.user_id = u.id
      ORDER BY d.upload_date DESC
      LIMIT 3
    `);for(let e of i)t.push({id:`document-${e.id}`,type:"document",title:"Documento procesado",description:e.file_name||"Documento sin nombre",timestamp:e.upload_date,user:e.first_name?{name:`${e.first_name} ${e.last_name}`,email:e.email}:void 0});return t.sort((e,t)=>new Date(t.timestamp).getTime()-new Date(e.timestamp).getTime()).slice(0,10)}catch(e){return[]}}async function m(e){try{let e=await d();return o.NextResponse.json({success:!0,data:e,timestamp:new Date().toISOString()})}catch(e){return o.NextResponse.json({success:!1,error:"Failed to fetch dashboard statistics",details:e instanceof Error?e.message:"Unknown error"},{status:500})}}let l=new i.AppRouteRouteModule({definition:{kind:a.RouteKind.APP_ROUTE,page:"/api/dashboard/stats/route",pathname:"/api/dashboard/stats",filename:"route",bundlePath:"app/api/dashboard/stats/route"},resolvedPagePath:"/home/semper/dashboard-monitor/src/app/api/dashboard/stats/route.ts",nextConfigOutput:"standalone",userland:s}),{workAsyncStorage:_,workUnitAsyncStorage:x,serverHooks:E}=l;function f(){return(0,n.patchFetch)({workAsyncStorage:_,workUnitAsyncStorage:x})}},66136:e=>{"use strict";e.exports=require("timers")},74075:e=>{"use strict";e.exports=require("zlib")},78335:()=>{},79428:e=>{"use strict";e.exports=require("buffer")},79551:e=>{"use strict";e.exports=require("url")},91645:e=>{"use strict";e.exports=require("net")},94735:e=>{"use strict";e.exports=require("events")},96487:()=>{}};var t=require("../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),s=t.X(0,[4447,580,6101],()=>r(64933));module.exports=s})();