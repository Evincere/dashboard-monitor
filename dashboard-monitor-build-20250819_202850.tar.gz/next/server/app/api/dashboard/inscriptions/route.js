(()=>{var t={};t.id=6932,t.ids=[6932],t.modules={3295:t=>{"use strict";t.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:t=>{"use strict";t.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},19771:t=>{"use strict";t.exports=require("process")},27910:t=>{"use strict";t.exports=require("stream")},28303:t=>{function e(t){var e=Error("Cannot find module '"+t+"'");throw e.code="MODULE_NOT_FOUND",e}e.keys=()=>[],e.resolve=e,e.id=28303,t.exports=e},28354:t=>{"use strict";t.exports=require("util")},29294:t=>{"use strict";t.exports=require("next/dist/server/app-render/work-async-storage.external.js")},34631:t=>{"use strict";t.exports=require("tls")},41204:t=>{"use strict";t.exports=require("string_decoder")},44870:t=>{"use strict";t.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},55511:t=>{"use strict";t.exports=require("crypto")},63033:t=>{"use strict";t.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},66136:t=>{"use strict";t.exports=require("timers")},67719:(t,e,r)=>{"use strict";r.d(e,{$A:()=>u,$y:()=>p,DK:()=>R,Hs:()=>l,L:()=>x,ME:()=>y,Np:()=>d,Q2:()=>h,TD:()=>E,UD:()=>T,Y4:()=>o,c$:()=>O,eW:()=>a,gG:()=>c,he:()=>f,m5:()=>m,sF:()=>_});var s=r(46101);let n=null;function i(){if(!n){let t={host:process.env.DB_HOST||"127.0.0.1",port:parseInt(process.env.DB_PORT||"3307"),user:process.env.DB_USER||"root",password:process.env.DB_PASSWORD||"root1234",database:process.env.DB_DATABASE||"mpd_concursos",connectionLimit:10,waitForConnections:!0,queueLimit:0,multipleStatements:!1,dateStrings:!1,supportBigNumbers:!0,bigNumberStrings:!1,charset:"utf8mb4"};(n=s.createPool(t)).on("error",t=>{})}return n}async function o(){let t=i();return await t.getConnection()}async function a(t,e){let r=i(),s=await r.getConnection();try{return await s.execute(t,e)}catch(t){throw t}finally{s.release()}}async function c(){return{tables:[],views:[],message:"Schema introspection temporarily disabled"}}async function u(){return{tablesCount:60,message:"Schema overview temporarily using mock data"}}async function p(){return{version:"8.0.43",message:"Database metadata temporarily using mock data"}}async function d(){return{isValid:!0,issues:[],message:"Schema validation temporarily disabled"}}async function m(){return[{TABLE_NAME:"user_entity",total_size_mb:5}]}async function l(){return[]}async function E(){return[]}async function O(){return[]}async function h(){return[]}async function x(){return[]}async function R(){return[]}async function _(){return[]}async function y(){return[]}async function f(){return[]}function T(){return{totalConnections:0,activeConnections:0}}},74075:t=>{"use strict";t.exports=require("zlib")},78335:()=>{},79428:t=>{"use strict";t.exports=require("buffer")},79551:t=>{"use strict";t.exports=require("url")},91645:t=>{"use strict";t.exports=require("net")},94735:t=>{"use strict";t.exports=require("events")},95537:(t,e,r)=>{"use strict";r.r(e),r.d(e,{patchFetch:()=>O,routeModule:()=>d,serverHooks:()=>E,workAsyncStorage:()=>m,workUnitAsyncStorage:()=>l});var s={};r.r(s),r.d(s,{GET:()=>p});var n=r(96559),i=r(48088),o=r(37719),a=r(32190),c=r(67719);let u=new Map;async function p(){try{let t="dashboard-inscriptions",e=function(t){let e=u.get(t);return e&&Date.now()-e.timestamp<3e4?e.data:(u.delete(t),null)}(t);if(e)return a.NextResponse.json({...e,cached:!0,timestamp:new Date().toISOString()});let r=await (0,c.Y4)(),[s,n,i,o,p,d]=await Promise.all([r.execute("SELECT COUNT(*) as total FROM inscriptions"),r.execute(`
        SELECT 
          COALESCE(status, 'Sin especificar') as status,
          COUNT(*) as count
        FROM inscriptions 
        GROUP BY status
        ORDER BY count DESC
      `),r.execute(`
        SELECT COUNT(*) as total
        FROM inscriptions 
        WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
      `),r.execute(`
        SELECT 
          c.title as contest_title,
          c.id as contest_id,
          COUNT(i.id) as inscription_count
        FROM inscriptions i
        JOIN contests c ON i.contest_id = c.id
        GROUP BY c.id, c.title
        ORDER BY inscription_count DESC
        LIMIT 10
      `),r.execute(`
        SELECT 
          DATE_FORMAT(created_at, '%Y-%m') as month,
          COUNT(*) as count
        FROM inscriptions 
        WHERE created_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
        GROUP BY DATE_FORMAT(created_at, '%Y-%m')
        ORDER BY month ASC
      `),r.execute(`
        SELECT 
          MONTH(created_at) as month,
          MONTHNAME(created_at) as month_name,
          COUNT(*) as count
        FROM inscriptions 
        WHERE YEAR(created_at) = YEAR(NOW())
        GROUP BY MONTH(created_at), MONTHNAME(created_at)
        ORDER BY month ASC
      `)]),m={total:s[0][0]?.total||0,recent:i[0][0]?.total||0,byStatus:n[0].map(t=>({status:t.status,count:t.count})),byContest:o[0].map(t=>({contestId:t.contest_id,contestTitle:t.contest_title,count:t.inscription_count})),growth:p[0].map(t=>({month:t.month,count:t.count})),byMonth:d[0].map(t=>({month:t.month,monthName:t.month_name,count:t.count}))};return u.set(t,{data:m,timestamp:Date.now()}),a.NextResponse.json({...m,cached:!1,timestamp:new Date().toISOString()})}catch(t){return a.NextResponse.json({error:"Failed to fetch inscription statistics",timestamp:new Date().toISOString()},{status:500})}}let d=new n.AppRouteRouteModule({definition:{kind:i.RouteKind.APP_ROUTE,page:"/api/dashboard/inscriptions/route",pathname:"/api/dashboard/inscriptions",filename:"route",bundlePath:"app/api/dashboard/inscriptions/route"},resolvedPagePath:"/home/semper/dashboard-monitor/src/app/api/dashboard/inscriptions/route.ts",nextConfigOutput:"standalone",userland:s}),{workAsyncStorage:m,workUnitAsyncStorage:l,serverHooks:E}=d;function O(){return(0,o.patchFetch)({workAsyncStorage:m,workUnitAsyncStorage:l})}},96487:()=>{}};var e=require("../../../../webpack-runtime.js");e.C(t);var r=t=>e(e.s=t),s=e.X(0,[4447,580,6101],()=>r(95537));module.exports=s})();