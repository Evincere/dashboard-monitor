(()=>{var e={};e.id=203,e.ids=[203],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},19771:e=>{"use strict";e.exports=require("process")},27910:e=>{"use strict";e.exports=require("stream")},28303:e=>{function t(e){var t=Error("Cannot find module '"+e+"'");throw t.code="MODULE_NOT_FOUND",t}t.keys=()=>[],t.resolve=t,t.id=28303,e.exports=t},28354:e=>{"use strict";e.exports=require("util")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},34631:e=>{"use strict";e.exports=require("tls")},41204:e=>{"use strict";e.exports=require("string_decoder")},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},51397:(e,t,r)=>{"use strict";r.r(t),r.d(t,{patchFetch:()=>h,routeModule:()=>x,serverHooks:()=>g,workAsyncStorage:()=>f,workUnitAsyncStorage:()=>S});var s={};r.r(s),r.d(s,{GET:()=>O,POST:()=>R});var a=r(96559),n=r(48088),o=r(37719),i=r(32190),u=r(67719),c=r(72289),l=r(35282);let m=c.Ik({name:c.Yj().min(1,"Name is required").max(255),username:c.Yj().min(3,"Username must be at least 3 characters").max(50),email:c.Yj().email("Invalid email format").max(255),password:c.Yj().min(6,"Password must be at least 6 characters"),role:c.k5(["ROLE_ADMIN","ROLE_USER"]).default("ROLE_USER"),status:c.k5(["ACTIVE","INACTIVE","BLOCKED"]).default("ACTIVE")});c.Ik({name:c.Yj().min(1,"Name is required").max(255).optional(),username:c.Yj().min(3,"Username must be at least 3 characters").max(50).optional(),email:c.Yj().email("Invalid email format").max(255).optional(),role:c.k5(["ROLE_ADMIN","ROLE_USER"]).optional(),status:c.k5(["ACTIVE","INACTIVE","BLOCKED"]).optional()});let p=new Map;function d(e){let t=p.get(e);return t&&Date.now()-t.timestamp<3e4?t.data:(p.delete(e),null)}function E(e,t){p.set(e,{data:t,timestamp:Date.now()})}async function O(e){try{let{searchParams:t}=new URL(e.url),r=t.get("search")||"",s=t.get("role")||"",a=t.get("status")||"",n=parseInt(t.get("page")||"1"),o=parseInt(t.get("limit")||"10"),c=(n-1)*o;if("true"===t.get("stats")){let e="dashboard-users",t=d(e);if(t)return i.NextResponse.json({...t,cached:!0,timestamp:new Date().toISOString()});let r=await (0,u.Y4)(),[s,a,n,o,c,l]=await Promise.all([r.execute("SELECT COUNT(*) as total FROM users"),r.execute(`
          SELECT COUNT(*) as total 
          FROM users 
          WHERE status = 'ACTIVE'
        `),r.execute(`
          SELECT 
            role,
            COUNT(*) as count
          FROM users 
          GROUP BY role
          ORDER BY count DESC
        `),r.execute(`
          SELECT 
            status,
            COUNT(*) as count
          FROM users 
          GROUP BY status
          ORDER BY count DESC
        `),r.execute(`
          SELECT COUNT(*) as total
          FROM users 
          WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
        `),r.execute(`
          SELECT 
            DATE_FORMAT(created_at, '%Y-%m') as month,
            COUNT(*) as count
          FROM users 
          WHERE created_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
          GROUP BY DATE_FORMAT(created_at, '%Y-%m')
          ORDER BY month ASC
        `)]);r.release();let m={total:s[0][0]?.total||0,active:a[0][0]?.total||0,recent:c[0][0]?.total||0,byRole:n[0].map(e=>({role:e.role,count:e.count})),byStatus:o[0].map(e=>({status:e.status,count:e.count})),growth:l[0].map(e=>({month:e.month,count:e.count}))};return E(e,m),i.NextResponse.json({...m,cached:!1,timestamp:new Date().toISOString()})}let l=`users-${r}-${s}-${a}-${n}-${o}`,m=d(l);if(m)return i.NextResponse.json({...m,cached:!0,timestamp:new Date().toISOString()});let p=await (0,u.Y4)(),O="WHERE 1=1",R=[];if(r){O+=" AND (name LIKE ? OR email LIKE ? OR username LIKE ?)";let e=`%${r}%`;R.push(e,e,e)}s&&(O+=" AND role = ?",R.push(s)),a&&(O+=" AND status = ?",R.push(a));let x=`SELECT COUNT(*) as total FROM users ${O}`,[f]=await p.execute(x,R),S=f[0]?.total||0,g=`
      SELECT 
        HEX(id) as id,
        name,
        username,
        email,
        role,
        status,
        created_at,
        updated_at,
        last_login
      FROM users 
      ${O}
      ORDER BY created_at DESC
      LIMIT ? OFFSET ?
    `,[h]=await p.execute(g,[...R,o,c]);p.release();let D={users:h.map(e=>({id:e.id,name:e.name,username:e.username,email:e.email,role:e.role,status:e.status,registrationDate:e.created_at,updatedAt:e.updated_at,lastLogin:e.last_login})),pagination:{page:n,limit:o,total:S,totalPages:Math.ceil(S/o),hasNext:n<Math.ceil(S/o),hasPrev:n>1}};return E(l,D),i.NextResponse.json({...D,cached:!1,timestamp:new Date().toISOString()})}catch(e){return i.NextResponse.json({error:"Failed to fetch users",details:e instanceof Error?e.message:"Unknown error",timestamp:new Date().toISOString()},{status:500})}}async function R(e){try{let t=await e.json(),r=m.parse(t),s=await (0,u.Y4)(),[a]=await s.execute("SELECT id FROM users WHERE username = ? OR email = ?",[r.username,r.email]);if(a.length>0)return s.release(),i.NextResponse.json({error:"Username or email already exists"},{status:409});let[n]=await s.execute(`INSERT INTO users (id, name, username, email, password, role, status, created_at, updated_at) 
       VALUES (UUID_TO_BIN(UUID()), ?, ?, ?, ?, ?, ?, NOW(), NOW())`,[r.name,r.username,r.email,r.password,r.role,r.status]);return s.release(),Array.from(p.keys()).filter(e=>e.startsWith("users-")).forEach(e=>p.delete(e)),p.delete("dashboard-users"),i.NextResponse.json({message:"User created successfully",userId:n.insertId,timestamp:new Date().toISOString()},{status:201})}catch(e){if(e instanceof l.G)return i.NextResponse.json({error:"Validation error",details:e.errors,timestamp:new Date().toISOString()},{status:400});return i.NextResponse.json({error:"Failed to create user",details:e instanceof Error?e.message:"Unknown error",timestamp:new Date().toISOString()},{status:500})}}let x=new a.AppRouteRouteModule({definition:{kind:n.RouteKind.APP_ROUTE,page:"/api/dashboard/users/route",pathname:"/api/dashboard/users",filename:"route",bundlePath:"app/api/dashboard/users/route"},resolvedPagePath:"/home/semper/dashboard-monitor/src/app/api/dashboard/users/route.ts",nextConfigOutput:"standalone",userland:s}),{workAsyncStorage:f,workUnitAsyncStorage:S,serverHooks:g}=x;function h(){return(0,o.patchFetch)({workAsyncStorage:f,workUnitAsyncStorage:S})}},55511:e=>{"use strict";e.exports=require("crypto")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},66136:e=>{"use strict";e.exports=require("timers")},67719:(e,t,r)=>{"use strict";r.d(t,{$A:()=>c,$y:()=>l,DK:()=>f,Hs:()=>d,L:()=>x,ME:()=>g,Np:()=>m,Q2:()=>R,TD:()=>E,UD:()=>D,Y4:()=>o,c$:()=>O,eW:()=>i,gG:()=>u,he:()=>h,m5:()=>p,sF:()=>S});var s=r(46101);let a=null;function n(){if(!a){let e={host:process.env.DB_HOST||"127.0.0.1",port:parseInt(process.env.DB_PORT||"3307"),user:process.env.DB_USER||"root",password:process.env.DB_PASSWORD||"root1234",database:process.env.DB_DATABASE||"mpd_concursos",connectionLimit:10,waitForConnections:!0,queueLimit:0,multipleStatements:!1,dateStrings:!1,supportBigNumbers:!0,bigNumberStrings:!1,charset:"utf8mb4"};(a=s.createPool(e)).on("error",e=>{})}return a}async function o(){let e=n();return await e.getConnection()}async function i(e,t){let r=n(),s=await r.getConnection();try{return await s.execute(e,t)}catch(e){throw e}finally{s.release()}}async function u(){return{tables:[],views:[],message:"Schema introspection temporarily disabled"}}async function c(){return{tablesCount:60,message:"Schema overview temporarily using mock data"}}async function l(){return{version:"8.0.43",message:"Database metadata temporarily using mock data"}}async function m(){return{isValid:!0,issues:[],message:"Schema validation temporarily disabled"}}async function p(){return[{TABLE_NAME:"user_entity",total_size_mb:5}]}async function d(){return[]}async function E(){return[]}async function O(){return[]}async function R(){return[]}async function x(){return[]}async function f(){return[]}async function S(){return[]}async function g(){return[]}async function h(){return[]}function D(){return{totalConnections:0,activeConnections:0}}},74075:e=>{"use strict";e.exports=require("zlib")},78335:()=>{},79428:e=>{"use strict";e.exports=require("buffer")},79551:e=>{"use strict";e.exports=require("url")},91645:e=>{"use strict";e.exports=require("net")},94735:e=>{"use strict";e.exports=require("events")},96487:()=>{}};var t=require("../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),s=t.X(0,[4447,580,6101,2289],()=>r(51397));module.exports=s})();