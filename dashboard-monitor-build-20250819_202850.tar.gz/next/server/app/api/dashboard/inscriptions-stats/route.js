(()=>{var t={};t.id=2246,t.ids=[2246],t.modules={3295:t=>{"use strict";t.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:t=>{"use strict";t.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},19771:t=>{"use strict";t.exports=require("process")},27910:t=>{"use strict";t.exports=require("stream")},28303:t=>{function e(t){var e=Error("Cannot find module '"+t+"'");throw e.code="MODULE_NOT_FOUND",e}e.keys=()=>[],e.resolve=e,e.id=28303,t.exports=e},28354:t=>{"use strict";t.exports=require("util")},29294:t=>{"use strict";t.exports=require("next/dist/server/app-render/work-async-storage.external.js")},34631:t=>{"use strict";t.exports=require("tls")},35324:(t,e,s)=>{"use strict";s.r(e),s.d(e,{patchFetch:()=>O,routeModule:()=>E,serverHooks:()=>_,workAsyncStorage:()=>D,workUnitAsyncStorage:()=>m});var r={};s.r(r),s.d(r,{GET:()=>l});var i=s(96559),n=s(48088),a=s(37719),o=s(32190),c=s(46101);let p={host:process.env.DB_HOST||"localhost",port:parseInt(process.env.DB_PORT||"3306"),user:process.env.DB_USER||"root",password:process.env.DB_PASSWORD||"root1234",database:process.env.DB_DATABASE||"mpd_concursos",timezone:"+00:00"},d={COMPLETED_WITH_DOCS:{label:"Completas para Revisi\xf3n",description:"Inscripciones con documentaci\xf3n completa lista para evaluaci\xf3n"},ACTIVE:{label:"En Proceso",description:"Inscripciones activas en proceso de completar documentaci\xf3n"},COMPLETED_PENDING_DOCS:{label:"Documentaci\xf3n Pendiente",description:"Inscripciones completadas pero con documentos faltantes"},APPROVED:{label:"Aprobadas",description:"Inscripciones aprobadas por la administraci\xf3n"},REJECTED:{label:"Rechazadas",description:"Inscripciones rechazadas"},CANCELLED:{label:"Canceladas",description:"Inscripciones canceladas por el usuario"},FROZEN:{label:"Congeladas",description:"Inscripciones temporalmente suspendidas"},PENDING:{label:"Pendientes",description:"Inscripciones en espera de revisi\xf3n inicial"}};async function u(t=null){let e=null;try{let s;e=await c.createConnection(p);let r=t?`AND contest_id = ${t}`:"",i=t?`WHERE contest_id = ${t}`:"",n=t?`WHERE contest_id = ${t} AND`:"WHERE",[a]=await e.execute(`
      SELECT COUNT(*) as count FROM user_entity
    `),o=a[0]?.count||0,[u]=await e.execute(`
      SELECT COUNT(*) as count FROM inscriptions ${i}
    `),l=u[0]?.count||0,E=o>0?Number((l/o*100).toFixed(1)):0,[D]=await e.execute(`
      SELECT 
        status,
        COUNT(*) as count
      FROM inscriptions
      ${i?`${i} AND`:"WHERE"} status IS NOT NULL
      GROUP BY status
      ORDER BY count DESC
    `),m=D.map(t=>({status:t.status,count:t.count,percentage:l>0?Number((t.count/l*100).toFixed(1)):0,label:d[t.status]?.label||t.status,description:d[t.status]?.description||"Estado de inscripci\xf3n"})),_=D.find(t=>"COMPLETED_WITH_DOCS"===t.status)?.count||0,O=D.find(t=>"COMPLETED_PENDING_DOCS"===t.status)?.count||0,T=D.find(t=>"ACTIVE"===t.status)?.count||0;if(t){let[r]=await e.execute(`
        SELECT 
          title,
          status,
          start_date,
          end_date,
          inscription_start_date,
          inscription_end_date
        FROM contests
        WHERE id = ?
      `,[t]),i=r[0];if(i){let t=i.inscription_start_date||i.start_date,e=i.inscription_end_date||i.end_date;"MULTIFUERO"!==i.title||i.inscription_start_date||(t="2025-07-30T00:00:00.000Z",e="2025-08-08T23:59:59.000Z");let r=null,n=null;if(e){let t=new Date(e);if((r=new Date(t)).setDate(r.getDate()+1),"MULTIFUERO"===i.title)r=new Date("2025-08-09T00:00:00.000Z"),n=new Date("2025-08-13T23:59:59.000Z");else{n=new Date(r);let t=0;for(;t<3;){n.setDate(n.getDate()+1);let e=n.getDay();0!==e&&6!==e&&t++}}}s={title:i.title,inscriptionPeriod:{start:t,end:e},documentationPeriod:{start:r?.toISOString()||null,end:n?.toISOString()||null},status:i.status}}}let R="",x=[];s&&s.inscriptionPeriod.start?(R=`
        SELECT 
          DATE_FORMAT(inscription_date, '%Y-%m-%d') as date,
          COUNT(*) as inscriptions
        FROM inscriptions
        WHERE contest_id = ? 
          AND inscription_date >= ?
          AND inscription_date IS NOT NULL
        GROUP BY DATE_FORMAT(inscription_date, '%Y-%m-%d')
        ORDER BY date ASC
      `,x=[t,s.inscriptionPeriod.start]):R=`
        SELECT 
          DATE_FORMAT(inscription_date, '%Y-%m') as month,
          COUNT(*) as inscriptions
        FROM inscriptions
        ${n} inscription_date >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
          AND inscription_date IS NOT NULL ${r}
        GROUP BY DATE_FORMAT(inscription_date, '%Y-%m')
        ORDER BY month ASC
      `;let[C]=await e.execute(R,x),N=0,S=C.map(t=>{N+=t.inscriptions,t.date||t.month;let e="";return{month:t.date?new Date(t.date).toLocaleDateString("es-ES",{month:"short",day:"numeric"}):new Date(t.month+"-01").toLocaleDateString("es-ES",{month:"short",year:"2-digit"}),inscriptions:t.inscriptions,cumulative:N}});return{totalUsers:o,totalInscriptions:l,inscriptionRate:E,statusBreakdown:m,readyForReview:_,pendingDocuments:O+T,timeline:S,contestInfo:s}}catch(t){return{totalUsers:0,totalInscriptions:0,inscriptionRate:0,statusBreakdown:[],readyForReview:0,pendingDocuments:0,timeline:[]}}finally{e&&await e.end()}}async function l(t){try{let{searchParams:e}=new URL(t.url),s=e.get("contestId"),r=await u(s?parseInt(s):null);return o.NextResponse.json({success:!0,data:r,timestamp:new Date().toISOString()})}catch(t){return o.NextResponse.json({success:!1,error:"Failed to fetch inscription statistics",details:t instanceof Error?t.message:"Unknown error"},{status:500})}}let E=new i.AppRouteRouteModule({definition:{kind:n.RouteKind.APP_ROUTE,page:"/api/dashboard/inscriptions-stats/route",pathname:"/api/dashboard/inscriptions-stats",filename:"route",bundlePath:"app/api/dashboard/inscriptions-stats/route"},resolvedPagePath:"/home/semper/dashboard-monitor/src/app/api/dashboard/inscriptions-stats/route.ts",nextConfigOutput:"standalone",userland:r}),{workAsyncStorage:D,workUnitAsyncStorage:m,serverHooks:_}=E;function O(){return(0,a.patchFetch)({workAsyncStorage:D,workUnitAsyncStorage:m})}},41204:t=>{"use strict";t.exports=require("string_decoder")},44870:t=>{"use strict";t.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},55511:t=>{"use strict";t.exports=require("crypto")},63033:t=>{"use strict";t.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},66136:t=>{"use strict";t.exports=require("timers")},74075:t=>{"use strict";t.exports=require("zlib")},78335:()=>{},79428:t=>{"use strict";t.exports=require("buffer")},79551:t=>{"use strict";t.exports=require("url")},91645:t=>{"use strict";t.exports=require("net")},94735:t=>{"use strict";t.exports=require("events")},96487:()=>{}};var e=require("../../../../webpack-runtime.js");e.C(t);var s=t=>e(e.s=t),r=e.X(0,[4447,580,6101],()=>s(35324));module.exports=r})();