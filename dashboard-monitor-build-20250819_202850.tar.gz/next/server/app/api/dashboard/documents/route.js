(()=>{var e={};e.id=9973,e.ids=[9973],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},17626:(e,t,s)=>{"use strict";s.r(t),s.d(t,{patchFetch:()=>_,routeModule:()=>m,serverHooks:()=>E,workAsyncStorage:()=>p,workUnitAsyncStorage:()=>l});var r={};s.r(r),s.d(r,{GET:()=>d});var n=s(96559),a=s(48088),i=s(37719),o=s(32190),u=s(67719);let c=new Map;async function d(){try{let e="dashboard-documents",t=function(e){let t=c.get(e);return t&&Date.now()-t.timestamp<3e4?t.data:(c.delete(e),null)}(e);if(t)return o.NextResponse.json({...t,cached:!0,timestamp:new Date().toISOString()});let s=await (0,u.Y4)(),[r,n,a,i,d,m]=await Promise.all([s.execute("SELECT COUNT(*) as total FROM documents"),s.execute(`
        SELECT 
          COALESCE(document_type, 'Sin especificar') as type,
          COUNT(*) as count
        FROM documents 
        GROUP BY document_type
        ORDER BY count DESC
      `),s.execute(`
        SELECT 
          COALESCE(validation_status, 'Sin validar') as status,
          COUNT(*) as count
        FROM documents 
        GROUP BY validation_status
        ORDER BY count DESC
      `),s.execute(`
        SELECT COUNT(*) as total
        FROM documents 
        WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
      `),s.execute(`
        SELECT 
          COUNT(*) as total_files,
          COALESCE(SUM(CASE WHEN file_size IS NOT NULL THEN file_size ELSE 0 END), 0) as total_size_bytes,
          COALESCE(AVG(CASE WHEN file_size IS NOT NULL THEN file_size ELSE NULL END), 0) as avg_size_bytes,
          COALESCE(MAX(file_size), 0) as max_size_bytes,
          COALESCE(MIN(CASE WHEN file_size > 0 THEN file_size ELSE NULL END), 0) as min_size_bytes
        FROM documents
      `),s.execute(`
        SELECT 
          u.name as user_name,
          u.email as user_email,
          COUNT(d.id) as document_count
        FROM documents d
        JOIN users u ON d.user_id = u.id
        GROUP BY u.id, u.name, u.email
        ORDER BY document_count DESC
        LIMIT 10
      `)]),p=d[0][0],l=Number((p?.total_size_bytes/0x40000000).toFixed(2)),E=Number((p?.avg_size_bytes/1048576).toFixed(2)),_=Number((p?.max_size_bytes/1048576).toFixed(2)),S=Number((p?.min_size_bytes/1048576).toFixed(2)),y={total:r[0][0]?.total||0,recent:i[0][0]?.total||0,byType:n[0].map(e=>({type:e.type,count:e.count})),byStatus:a[0].map(e=>({status:e.status,count:e.count})),storage:{totalFiles:p?.total_files||0,totalSizeGB:l,avgSizeMB:E,maxSizeMB:_,minSizeMB:S},topUsers:m[0].map(e=>({userName:e.user_name,userEmail:e.user_email,documentCount:e.document_count}))};return c.set(e,{data:y,timestamp:Date.now()}),o.NextResponse.json({...y,cached:!1,timestamp:new Date().toISOString()})}catch(e){return o.NextResponse.json({error:"Failed to fetch document statistics",timestamp:new Date().toISOString()},{status:500})}}let m=new n.AppRouteRouteModule({definition:{kind:a.RouteKind.APP_ROUTE,page:"/api/dashboard/documents/route",pathname:"/api/dashboard/documents",filename:"route",bundlePath:"app/api/dashboard/documents/route"},resolvedPagePath:"/home/semper/dashboard-monitor/src/app/api/dashboard/documents/route.ts",nextConfigOutput:"standalone",userland:r}),{workAsyncStorage:p,workUnitAsyncStorage:l,serverHooks:E}=m;function _(){return(0,i.patchFetch)({workAsyncStorage:p,workUnitAsyncStorage:l})}},19771:e=>{"use strict";e.exports=require("process")},27910:e=>{"use strict";e.exports=require("stream")},28303:e=>{function t(e){var t=Error("Cannot find module '"+e+"'");throw t.code="MODULE_NOT_FOUND",t}t.keys=()=>[],t.resolve=t,t.id=28303,e.exports=t},28354:e=>{"use strict";e.exports=require("util")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},34631:e=>{"use strict";e.exports=require("tls")},41204:e=>{"use strict";e.exports=require("string_decoder")},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},55511:e=>{"use strict";e.exports=require("crypto")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},66136:e=>{"use strict";e.exports=require("timers")},67719:(e,t,s)=>{"use strict";s.d(t,{$A:()=>c,$y:()=>d,DK:()=>x,Hs:()=>l,L:()=>y,ME:()=>C,Np:()=>m,Q2:()=>S,TD:()=>E,UD:()=>O,Y4:()=>i,c$:()=>_,eW:()=>o,gG:()=>u,he:()=>N,m5:()=>p,sF:()=>f});var r=s(46101);let n=null;function a(){if(!n){let e={host:process.env.DB_HOST||"127.0.0.1",port:parseInt(process.env.DB_PORT||"3307"),user:process.env.DB_USER||"root",password:process.env.DB_PASSWORD||"root1234",database:process.env.DB_DATABASE||"mpd_concursos",connectionLimit:10,waitForConnections:!0,queueLimit:0,multipleStatements:!1,dateStrings:!1,supportBigNumbers:!0,bigNumberStrings:!1,charset:"utf8mb4"};(n=r.createPool(e)).on("error",e=>{})}return n}async function i(){let e=a();return await e.getConnection()}async function o(e,t){let s=a(),r=await s.getConnection();try{return await r.execute(e,t)}catch(e){throw e}finally{r.release()}}async function u(){return{tables:[],views:[],message:"Schema introspection temporarily disabled"}}async function c(){return{tablesCount:60,message:"Schema overview temporarily using mock data"}}async function d(){return{version:"8.0.43",message:"Database metadata temporarily using mock data"}}async function m(){return{isValid:!0,issues:[],message:"Schema validation temporarily disabled"}}async function p(){return[{TABLE_NAME:"user_entity",total_size_mb:5}]}async function l(){return[]}async function E(){return[]}async function _(){return[]}async function S(){return[]}async function y(){return[]}async function x(){return[]}async function f(){return[]}async function C(){return[]}async function N(){return[]}function O(){return{totalConnections:0,activeConnections:0}}},74075:e=>{"use strict";e.exports=require("zlib")},78335:()=>{},79428:e=>{"use strict";e.exports=require("buffer")},79551:e=>{"use strict";e.exports=require("url")},91645:e=>{"use strict";e.exports=require("net")},94735:e=>{"use strict";e.exports=require("events")},96487:()=>{}};var t=require("../../../../webpack-runtime.js");t.C(e);var s=e=>t(t.s=e),r=t.X(0,[4447,580,6101],()=>s(17626));module.exports=r})();