(()=>{var e={};e.id=9787,e.ids=[9787],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},16681:(e,t,r)=>{"use strict";r.r(t),r.d(t,{patchFetch:()=>v,routeModule:()=>l,serverHooks:()=>m,workAsyncStorage:()=>x,workUnitAsyncStorage:()=>_});var s={};r.r(s),r.d(s,{GET:()=>d});var i=r(96559),o=r(48088),n=r(37719),a=r(32190),c=r(46101);let u={host:process.env.DB_HOST||"localhost",port:parseInt(process.env.DB_PORT||"3306"),user:process.env.DB_USER||"root",password:process.env.DB_PASSWORD||"root1234",database:process.env.DB_DATABASE||"mpd_concursos",timezone:"+00:00"};async function p(){let e=null;try{e=await c.createConnection(u);let[t]=await e.execute(`
      SELECT 
        c.id,
        c.title,
        c.category,
        c.class_,
        c.department,
        c.position,
        c.functions,
        c.status,
        c.start_date as startDate,
        c.end_date as endDate,
        c.inscription_start_date as inscriptionStartDate,
        c.inscription_end_date as inscriptionEndDate,
        c.bases_url,
        c.description_url,
        COUNT(i.id) as inscriptionCount
      FROM contests c
      LEFT JOIN inscriptions i ON i.contest_id = c.id
      GROUP BY c.id, c.title, c.category, c.class_, c.department, c.position, c.functions, c.status, 
               c.start_date, c.end_date, c.inscription_start_date, c.inscription_end_date, c.bases_url, c.description_url
      ORDER BY c.created_at DESC
    `);return t}catch(e){return[]}finally{e&&await e.end()}}async function d(e){try{let e=await p();return a.NextResponse.json({success:!0,data:e,timestamp:new Date().toISOString()})}catch(e){return a.NextResponse.json({success:!1,error:"Failed to fetch contests list",details:e instanceof Error?e.message:"Unknown error"},{status:500})}}let l=new i.AppRouteRouteModule({definition:{kind:o.RouteKind.APP_ROUTE,page:"/api/dashboard/contests-list/route",pathname:"/api/dashboard/contests-list",filename:"route",bundlePath:"app/api/dashboard/contests-list/route"},resolvedPagePath:"/home/semper/dashboard-monitor/src/app/api/dashboard/contests-list/route.ts",nextConfigOutput:"standalone",userland:s}),{workAsyncStorage:x,workUnitAsyncStorage:_,serverHooks:m}=l;function v(){return(0,n.patchFetch)({workAsyncStorage:x,workUnitAsyncStorage:_})}},19771:e=>{"use strict";e.exports=require("process")},27910:e=>{"use strict";e.exports=require("stream")},28303:e=>{function t(e){var t=Error("Cannot find module '"+e+"'");throw t.code="MODULE_NOT_FOUND",t}t.keys=()=>[],t.resolve=t,t.id=28303,e.exports=t},28354:e=>{"use strict";e.exports=require("util")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},34631:e=>{"use strict";e.exports=require("tls")},41204:e=>{"use strict";e.exports=require("string_decoder")},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},55511:e=>{"use strict";e.exports=require("crypto")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},66136:e=>{"use strict";e.exports=require("timers")},74075:e=>{"use strict";e.exports=require("zlib")},78335:()=>{},79428:e=>{"use strict";e.exports=require("buffer")},79551:e=>{"use strict";e.exports=require("url")},91645:e=>{"use strict";e.exports=require("net")},94735:e=>{"use strict";e.exports=require("events")},96487:()=>{}};var t=require("../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),s=t.X(0,[4447,580,6101],()=>r(16681));module.exports=s})();