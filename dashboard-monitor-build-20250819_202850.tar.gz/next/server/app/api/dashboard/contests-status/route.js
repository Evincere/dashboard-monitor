(()=>{var e={};e.id=8861,e.ids=[8861],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},19771:e=>{"use strict";e.exports=require("process")},27910:e=>{"use strict";e.exports=require("stream")},28303:e=>{function t(e){var t=Error("Cannot find module '"+e+"'");throw t.code="MODULE_NOT_FOUND",t}t.keys=()=>[],t.resolve=t,t.id=28303,e.exports=t},28354:e=>{"use strict";e.exports=require("util")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},34631:e=>{"use strict";e.exports=require("tls")},41204:e=>{"use strict";e.exports=require("string_decoder")},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},47888:(e,t,s)=>{"use strict";s.r(t),s.d(t,{patchFetch:()=>v,routeModule:()=>x,serverHooks:()=>m,workAsyncStorage:()=>E,workUnitAsyncStorage:()=>D});var r={};s.r(r),s.d(r,{GET:()=>l});var a=s(96559),o=s(48088),n=s(37719),i=s(32190),u=s(46101);let c={host:process.env.DB_HOST||"localhost",port:parseInt(process.env.DB_PORT||"3306"),user:process.env.DB_USER||"root",password:process.env.DB_PASSWORD||"root1234",database:process.env.DB_DATABASE||"mpd_concursos",timezone:"+00:00"},d={ACTIVE:"Activo",ARCHIVED:"Archivado",CANCELLED:"Cancelado",CLOSED:"Cerrado",DRAFT:"Borrador",FINISHED:"Finalizado",IN_EVALUATION:"En Evaluaci\xf3n",PAUSED:"Pausado",RESULTS_PUBLISHED:"Resultados Publicados",SCHEDULED:"Programado"};async function p(){let e=null;try{e=await u.createConnection(c);let[t]=await e.execute(`
      SELECT 
        status,
        COUNT(*) as count
      FROM contests
      WHERE status IS NOT NULL
      GROUP BY status
      ORDER BY count DESC
    `),s=t.reduce((e,t)=>e+t.count,0),r=[];for(let a of t){let[t]=await e.execute(`
        SELECT 
          id,
          title,
          category,
          department,
          start_date as startDate,
          end_date as endDate,
          inscription_start_date as inscriptionStartDate,
          inscription_end_date as inscriptionEndDate
        FROM contests
        WHERE status = ?
        ORDER BY created_at DESC
      `,[a.status]);r.push({status:a.status,count:a.count,percentage:s>0?Number((a.count/s*100).toFixed(1)):0,label:d[a.status]||a.status,contests:t})}return r}catch(e){return[]}finally{e&&await e.end()}}async function l(e){try{let e=await p();return i.NextResponse.json({success:!0,data:e,timestamp:new Date().toISOString()})}catch(e){return i.NextResponse.json({success:!1,error:"Failed to fetch contests by status",details:e instanceof Error?e.message:"Unknown error"},{status:500})}}let x=new a.AppRouteRouteModule({definition:{kind:o.RouteKind.APP_ROUTE,page:"/api/dashboard/contests-status/route",pathname:"/api/dashboard/contests-status",filename:"route",bundlePath:"app/api/dashboard/contests-status/route"},resolvedPagePath:"/home/semper/dashboard-monitor/src/app/api/dashboard/contests-status/route.ts",nextConfigOutput:"standalone",userland:r}),{workAsyncStorage:E,workUnitAsyncStorage:D,serverHooks:m}=x;function v(){return(0,n.patchFetch)({workAsyncStorage:E,workUnitAsyncStorage:D})}},55511:e=>{"use strict";e.exports=require("crypto")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},66136:e=>{"use strict";e.exports=require("timers")},74075:e=>{"use strict";e.exports=require("zlib")},78335:()=>{},79428:e=>{"use strict";e.exports=require("buffer")},79551:e=>{"use strict";e.exports=require("url")},91645:e=>{"use strict";e.exports=require("net")},94735:e=>{"use strict";e.exports=require("events")},96487:()=>{}};var t=require("../../../../webpack-runtime.js");t.C(e);var s=e=>t(t.s=e),r=t.X(0,[4447,580,6101],()=>s(47888));module.exports=r})();